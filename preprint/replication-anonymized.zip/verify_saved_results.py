#!/usr/bin/env python3
"""Verify saved labels/aggregates without accessing any corpus or service."""
import json, math, sys
from pathlib import Path
from collections import Counter

ROOT=Path(__file__).resolve().parent
def read(path): return json.loads((ROOT/path).read_text())
labels=read('data/local/candidate_adjudications.json')
rows=[r for r in labels['rows'] if not r['excluded_as_overlap']]
saved=read('data/local/adjudicated_summary.json')['adjudicated']['pooled_dedup']
for head,want in saved.items():
    selected=[r for r in rows if r['head']==head]
    c=Counter(r['label'] for r in selected)
    assert len(selected)==want['raw'],head
    assert sum(c[s] for s in labels['bare_subtypes'])==want['bare_verified'],head
    assert c['GOD_OPTATIVE']==want['god_optative'],head
assert len(rows)==596
assert sum(r['label'] in labels['bare_subtypes'] for r in rows)==220
assert sum(r['label']=='GOD_OPTATIVE' for r in rows)==23

pp=read('data/davies/tv_pp_shared_audit.json')
goal,reason=pp['T7a_to_hell'],pp['T7b_for_ving']
assert sum(x.get('accepted_shared',0) for x in goal['by_head'].values())==33
assert sum(x.get('accepted_shared',0) for x in reason['by_head'].values())==48
assert reason['totals']['accepted_all']==53
assert len(reason['accepted_me_rows'])==5
assert any(r['row']==64 and r['head']=='damn' for r in reason['accepted_me_rows'])
for q in [goal,reason]:
    for h,row in q['by_head'].items():
        assert row.get('raw_shared',0)-row.get('displayed_shared',0)==row['undisplayed_shared'],h
goal_damn=goal['by_head']['damn']['accepted_shared']
reason_dd=sum(reason['by_head'][h]['accepted_shared'] for h in ['damn','darn'])
goal_total=goal['totals']['accepted_shared']
reason_total=reason['totals']['accepted_shared']
goal_unseen=goal['totals']['undisplayed_shared']
reason_dd_unseen=sum(reason['by_head'][h]['undisplayed_shared'] for h in ['damn','darn'])
reason_other_unseen=reason['totals']['undisplayed_shared']-reason_dd_unseen
goal_low=goal_damn/goal_total
goal_high=(goal_damn+goal_unseen)/(goal_total+goal_unseen)
reason_low=reason_dd/(reason_total+reason_other_unseen)
reason_high=(reason_dd+reason_dd_unseen)/(reason_total+reason_dd_unseen)
gap=(goal_low-reason_high)*100
assert round(gap,2)==70.97
assert round(reason['by_head']['damn']['accepted_shared']/1627*20107,2)==123.58

sys.path.insert(0,str(ROOT/'analysis'))
import kilgarriff_dunning_audit as audit
actual=audit.run_dunning_pp_analysis()
expected=read('data/kilgarriff_dunning_summary.json')['dunning_pp']
assert actual==expected,'Saved PP statistical block differs from recomputation'
print('PASS: 596 deduplicated candidates, 220 subjectless tokens and 23 overt-God optatives.')
print('PASS: 53 reason-PP tokens = 48 shared pronouns + 5 self-curses; corrected target row 64.')
print(f'PASS: goal bounds {goal_low:.4%}-{goal_high:.4%}; reason bounds {reason_low:.4%}-{reason_high:.4%}; gap {gap:.2f} points.')
print('PASS: D14 damn-it benchmark 123.58; entire saved PP statistical block reproduced.')
print('These checks verify consistency conditional on existing labels; they do not independently adjudicate corpus contexts.')
