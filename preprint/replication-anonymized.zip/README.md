# Anonymized replication materials

This archive accompanies the article *Damn him to hell, fuck me for giving a shit, thank you for coming: How Far Generalizations Reach in English* and its supplementary materials. It was assembled from the corrected local version dated 24 November 2026.

## Contents and limits

- `analysis/`: extraction, adjudication and analysis code, dated results summaries, and the TV frame-sample aggregates.
- `data/`: saved aggregate outputs and a text-free Tier-1 candidate table containing existing adjudication labels, source identifiers and overlap flags.
- `design/`: exact query sheets and the original study design. The dated summaries and Supplementary Table S1 document subsequent queries and corrections. Earlier numbers in chronological notes remain historical; current PP counts are in `tv_pp_shared_audit.json` and `kilgarriff_dunning_summary.json`.
- `verify_saved_results.py`: checks that can run using only this archive and Python 3's standard library.

Raw corpus texts, downloaded concordances, local extraction text, confidential review reports, author information and repository links are excluded. Full extraction and line-context re-adjudication require independent access to BNC Baby, CABNC, OANC and the relevant online corpora. Scripts expecting omitted raw inputs cannot be rerun from this archive alone. The portable checks establish consistency of saved labels and aggregates, not independent verification of their linguistic coding.

Run `python3 verify_saved_results.py` from the archive root. To rerun corpus-dependent scripts, supply the licensed inputs at the documented paths and replace `/path/to/local` with the appropriate local directory. Online corpus queries must be run manually through the licensed interfaces; the code parses locally retained exports and does not scrape those services.

This is an anonymized review copy. Source files are unchanged except for removal of personal paths and identifiers. The manuscript and supplement define the analysis and interpretive scope. The original Tier-1 code retains exploratory tests that the article does not use; those outputs should not be treated as inferential results reported by the article.
