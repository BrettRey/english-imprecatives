# B2 Spoken BNC2014 Queries (Spontaneous Contemporary British Conversation)

**Corpus:** Spoken BNC2014 (~11.42M words of unscripted British conversation, 2012–2016; Love et al. 2017), via Lancaster CQPweb (`https://cqpweb.lancs.ac.uk/` $\to$ *British National Corpus 2014 (Spoken)*, CQP syntax mode).
**Goal:** Test whether the living vs. period-bound head split, `fuck`-euphemism distribution, overt `God` split, and `to hell` vs. `for V-ing` pattern hold in unscripted contemporary conversation (directly answering Claude #8, Muse #5, and §7).

> **Tip in CQPweb:** Switch **Query mode** to **CQP syntax**. For each query, **Frequency breakdown** (words only) gives the full head-by-target table; for small queries (< 100 hits) or specific heads, **Download concordance** (tab-delimited or plain text) gives full context + text IDs.

---

### `B2-1a` — Core 13 heads + NP starters
```cqp
[word="damn|bless|fuck|sod|bugger|screw|blast|curse|hang|drat|darn|dash|dang"%c] [word="it|you|him|her|them|me|us|this|that|these|those|the|my|your|his|their"%c]
```
- **Need:** Frequency breakdown by matched pair (plus concordances for any low-frequency heads: `blast`, `curse`, `drat`, `darn`, `dash`, `dang`, and all `DET/POSS` full-NP hits).
- *(Optional tiny companion `B2-1b` for univerbated forms: `[word="dammit|goddammit"%c]` — just hit count + text count.)*

---

### `B2-2` — `fuck`-euphemisms + NP starters (tests TV censorship vs. spoken usage)
```cqp
[word="frak|feck|fudge|eff|frig|frick"%c] [word="it|you|him|her|them|me|us|this|that|these|those|the|my|your|his|their"%c]
```
- **Need:** Full frequency breakdown + all concordance lines (likely small enough to paste/download completely!).

---

### `B2-3` — Overt `God` + core heads (and `rot`)
```cqp
[word="god"%c] [word="damn|bless|curse|fuck|screw|sod|bugger|blast|darn|dang|drat|dash|rot"%c] [word="it|you|him|her|them|me|us|this|that|the|my|your|his|her|their"%c]
```
- **Need:** Frequency breakdown (and concordance lines for non-`it`, non-`bless you` hits if small).

---

### `B2-4a` & `B2-4b` — `to hell` vs. `for V-ing` in spontaneous conversation
- **`B2-4a` (`to hell`):**
```cqp
[word="damn|bless|fuck|sod|bugger|screw|blast|curse|darn|dang|drat|dash|eff|frak"%c] [word="it|you|him|her|them|me|us"%c] [word="to"%c] [word="hell"%c]
```
- **`B2-4b` (`for V-ing`):**
```cqp
[word="damn|bless|fuck|sod|bugger|screw|blast|curse|darn|dang|drat|dash|eff|frak"%c] [word="you|him|her|them|me|us"%c] [word="for"%c] [word=".*ing"%c]
```
- **Need:** All concordance lines (likely very small — easy to audit 100%!).

---

### `B2-5` *(Optional)* — Non-taboo British living heads (`stuff`, `confound`, `bother`) + `yay`/`boo`
- **`B2-5a` (`confound` + `stuff`):**
```cqp
[word="confound"%c] [word="it|you|him|her|them|me|this|that|the"%c]
```
```cqp
[word="stuff"%c] [word="it|this|that|you|him|her|them"%c]
```
- **`B2-5b` (`yay`/`boo` + pronouns / determiners):**
```cqp
[word="yay|boo"%c] [word="me|you|him|her|them|us|this|that|the|my|your"%c]
```
